# -*- coding: utf-8 -*-
print(list(range(100)))
