Wexpect util
============

.. automodule:: wexpect.wexpect_util

Functions
---------

.. automethod:: wexpect.wexpect_util.str2bool
.. automethod:: wexpect.wexpect_util.spam
.. automethod:: wexpect.wexpect_util.init_logger
.. automethod:: wexpect.wexpect_util.split_command_line
.. automethod:: wexpect.wexpect_util.join_args

ExceptionPexpect
----------------

.. autoclass:: ExceptionPexpect

EOF
---

.. autoclass:: EOF

TIMEOUT
-------

.. autoclass:: TIMEOUT
